import { supabase } from './supabase.js'

async function loadSuppliers(){

 const {
  data:{user}
 } = await supabase.auth.getUser()

 const { data:profile } = await supabase
 .from('profiles')
 .select('*')
 .eq('id',user.id)
 .single()

 const { data:suppliers } = await supabase
 .from('suppliers')
 .select('*')
 .eq('company_id',profile.company_id)

 let html=''

 suppliers.forEach(supplier=>{
  html += `
  <tr>
   <td>${supplier.name}</td>
   <td>${supplier.phone}</td>
   <td>${supplier.email}</td>
  </tr>
  `
 })

 document.getElementById('suppliers').innerHTML=html
}

window.addSupplier = async function(){

 const name=document.getElementById('supplierName').value
 const phone=document.getElementById('supplierPhone').value
 const email=document.getElementById('supplierEmail').value

 const {
  data:{user}
 } = await supabase.auth.getUser()

 const { data:profile } = await supabase
 .from('profiles')
 .select('*')
 .eq('id',user.id)
 .single()

 await supabase
 .from('suppliers')
 .insert([
 {
  company_id:profile.company_id,
  name,
  phone,
  email
 }
 ])

 loadSuppliers()
}

loadSuppliers()