window.pay = function(){

 const price = Number(document.getElementById('price').value)
 const quantity = Number(document.getElementById('quantity').value)
 const discount = Number(document.getElementById('discount').value || 0)

 const subtotal = price * quantity

 const iva = subtotal * 0.13

 const total = subtotal + iva - discount

 const cash = Number(document.getElementById('cashReceived').value)

 const change = cash - total

 alert(`Total: ₡${total}\nCambio: ₡${change}`)
}

window.generatePDF = function(){

 const { jsPDF } = window.jspdf

 const doc = new jsPDF()

 doc.text('Factura BYA Solutions POS',20,20)

 doc.text('Gracias por su compra',20,40)

 doc.save('factura.pdf')
}
