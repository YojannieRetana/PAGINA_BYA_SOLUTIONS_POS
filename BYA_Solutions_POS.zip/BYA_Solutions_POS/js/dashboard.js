import { supabase } from './supabase.js'

async function validateSession(){

 const {
  data:{user}
 } = await supabase.auth.getUser()

 if(!user){
  window.location='index.html'
 }
}

validateSession()

window.logout = async function(){
 await supabase.auth.signOut()
 window.location='index.html'
}