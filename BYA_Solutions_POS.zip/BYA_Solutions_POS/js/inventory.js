import { supabase } from './supabase.js'

async function loadProducts(){

 const { data:products } = await supabase
 .from('products')
 .select('*')

 let html=''

 products.forEach(product=>{
  html += `
  <tr>
   <td>${product.name}</td>
   <td>₡${product.price}</td>
  </tr>
  `
 })

 document.getElementById('products').innerHTML=html
}

window.addProduct = async function(){

 const name=document.getElementById('productName').value
 const price=document.getElementById('productPrice').value

 await supabase
 .from('products')
 .insert([
 {
  name,
  price
 }
 ])

 loadProducts()
}

loadProducts()