import { supabase } from './supabase.js'

async function loadCustomers(){

 const {
  data:{user}
 } = await supabase.auth.getUser()

 if(!user){
  window.location='index.html'
  return
 }

 const { data:profile } = await supabase
 .from('profiles')
 .select('*')
 .eq('id',user.id)
 .single()

 const { data:customers } = await supabase
 .from('customers')
 .select('*')
 .eq('company_id',profile.company_id)

 let html=''

 customers.forEach(customer=>{
  html += `
  <tr>
   <td>${customer.name}</td>
   <td>${customer.phone}</td>
   <td>${customer.email}</td>
  </tr>
  `
 })

 document.getElementById('customers').innerHTML=html
}

window.addCustomer = async function(){

 const name=document.getElementById('customerName').value
 const phone=document.getElementById('customerPhone').value
 const email=document.getElementById('customerEmail').value

 const {
  data:{user}
 } = await supabase.auth.getUser()

 const { data:profile } = await supabase
 .from('profiles')
 .select('*')
 .eq('id',user.id)
 .single()

 await supabase
 .from('customers')
 .insert([
 {
  company_id:profile.company_id,
  name,
  phone,
  email
 }
 ])

 loadCustomers()
}

loadCustomers()