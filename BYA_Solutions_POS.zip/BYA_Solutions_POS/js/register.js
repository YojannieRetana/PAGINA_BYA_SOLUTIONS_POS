import { supabase } from './supabase.js'

window.register = async function(){

 const companyName = document.getElementById('companyName').value
 const email = document.getElementById('email').value
 const password = document.getElementById('password').value

 const plan = document.querySelector('input[name="plan"]:checked')?.value

 if(!plan){
  alert('Selecciona un plan')
  return
 }

 const {
  data,
  error
 } = await supabase.auth.signUp({

  email,
  password,

  options:{

   emailRedirectTo:
   'http://localhost/BYA-Solutions-POS/dashboard.html'

  }

 })

 if(error){
  alert(error.message)
  return
 }

 const user = data.user

 const { data:company } = await supabase
 .from('companies')
 .insert([
 {
  name:companyName,
  plan
 }
 ])
 .select()
 .single()

 await supabase
 .from('profiles')
 .insert([
 {
  id:user.id,
  company_id:company.id,
  email,
  role:'admin'
 }
 ])

 alert('Cuenta creada. Revisa tu correo para confirmar la cuenta.')

 window.location='index.html'
}