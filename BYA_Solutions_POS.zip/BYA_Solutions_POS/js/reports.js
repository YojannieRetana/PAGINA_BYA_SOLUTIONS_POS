import { supabase } from './supabase.js'

async function loadReports(){

 const { data:sales } = await supabase
 .from('sales')
 .select('*')

 let total=0

 sales.forEach(sale=>{
  total += Number(sale.total)
 })

 console.log('Ventas:',total)
}

loadReports()